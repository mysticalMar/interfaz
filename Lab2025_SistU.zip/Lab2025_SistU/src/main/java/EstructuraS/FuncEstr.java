/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EstructuraS;
import ObjetosU.*;
/**
 *
 * @author maria
 */
public interface FuncEstr {
    public int cardinalidad();
    public Boolean inStruc(Persona p);
    public void muestroEstruc();
    }

